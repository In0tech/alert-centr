import os, re, sys
import traceback
import threading

import json
import configparser
import datetime

import requests
import ipaddress

import clickhouse_connect

from flask import Flask, request, Response

sys.stdout.reconfigure(encoding="utf-8")


#sys.path.append('../../services')
#from services.utils import send_notification
from utils import send_notification


from notifyavr import notify_on_duty_team


config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), '..',  'alert_center.conf'))

BUZZ_URL = config.get('BUZZ_API', 'BUZZ_URL')
MITIGATIONS_BOT_TOKEN = config.get('BUZZ_API', 'MITIGATIONS_BOT_TOKEN')

CLICKHOUSE_HOST = config.get('CLICKHOUSE', 'HOST')
CLICKHOUSE_PORT = config.getint('CLICKHOUSE', 'PORT')
CLICKHOUSE_USER = config.get('CLICKHOUSE', 'USER')
CLICKHOUSE_DATABASE = config.get('CLICKHOUSE', 'DATABASE')
clickhouse_client = clickhouse_connect.get_client(
    host=CLICKHOUSE_HOST, port=CLICKHOUSE_PORT,
    user=CLICKHOUSE_USER, database=CLICKHOUSE_DATABASE,
)

#NSPA_CHAT_ID = config.get('NSPA_BOT', 'NSPA_CHAT_ID')
#TEST_NSPA_CHAT_ID = config.get('NSPA_BOT', 'TEST_NSPA_CHAT_ID')
#NOTIFY_CHAT_ID = config.get('NSPA_BOT', 'NOTIFY_CHAT_ID')

NSPA_CHAT_ID = "922fcb57-6365-5cca-b7d7-e1c782af49bb" # nspa chat (data source)
TEST_NSPA_CHAT_ID = "3da31d89-dbd7-5569-bcfe-533bdfb80b83"  #  test nspa chat

# destination for all notifications (Use MITIGATIONS_BOT_TOKEN)
NOTIFY_CHAT_ID = "9267a608-8392-5447-8f25-b0c858c693d1"  # SOC - L1/L2_ADDoS 
#NOTIFY_CHAT_ID = "bcb9d7d3-c75b-5dec-a51c-b35c747149af" # test bots

NOTIFY_FAILURE_CHAT_ID = "ee60ac64-482a-5a4e-99d7-76f19f8579f2" # НСПА бот  


# Buzz "typing..." / "stop_typing" endpoints. Base is derived from BUZZ_URL
# (https://cts1.buzz.beeline.ru:4443) per Buzz API v3 events.
_BUZZ_BASE = BUZZ_URL.rsplit('/api/', 1)[0]
BUZZ_TYPING_URL = f"{_BUZZ_BASE}/api/v3/botx/events/typing"
BUZZ_STOP_TYPING_URL = f"{_BUZZ_BASE}/api/v3/botx/events/stop_typing"


def set_typing(chat_id, token=MITIGATIONS_BOT_TOKEN, stop=False):
    """Toggle the 'печатает...' indicator in a Buzz chat."""
    url = BUZZ_STOP_TYPING_URL if stop else BUZZ_TYPING_URL
    headers = {
        "authorization": f"Bearer {token}",
        "content-type": "application/json",
    }
    payload = {"group_chat_id": chat_id}
    try:
        requests.post(url, headers=headers, json=payload, timeout=10)
    except Exception as e:
        print(f"[nspa_bot] set_typing(stop={stop}) failed: {e}")


#NSPA_TEAM_USER_IDS = set(
#    uid.strip() for uid in config.get('NSPA_BOT', 'NSPA_TEAM_USER_IDS').split(',') if uid.strip()
#)
NSPA_TEAM_USER_IDS = [
    "a69bb41b-5db7-51c2-b747-c3181dd5823b",  # test (leo)
    
    "5f7ebffc-b7d5-5689-9e40-1e426372aa76",  # Vladislav Bochkov  
    "56cd9208-256b-5ec8-95df-048bc0e1cce9",  # Алексей Ледников 
    "6ec81866-71f7-5430-aebf-5bc0b3de229f",  # Дамир Якубов
    "5364b60e-9b82-5e6b-a9ff-db3d7fbd4679",  # ДС НСПА 
]
#NSPA_BOT_PORT = config.getint('NSPA_BOT', 'NSPA_BOT_PORT', fallback=6002)

AI_API_URL = config.get('AI_API', 'URL')
AI_API_KEY = config.get('AI_API', 'KEY')
AI_API_MODEL = config.get('AI_API', 'MODEL')



app = Flask(__name__)


# ---------------------------------------------------------------------------
# Regex-based extraction (primary path)
# ---------------------------------------------------------------------------

CIDR_RE = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2})?\b')
# TIME_RE = re.compile(r'\b([01]?\d|2[0-3]):([0-5]\d)\b')
# Start-time extraction is now handled by the LLM (see llm_extract_anomaly),
# which can also infer the correct day (e.g. a morning message about 23:00
# likely refers to the previous day).

ANOMALY_KEYWORDS = [
    'атак', 'аномал', 'ddos', 'флуд', 'нагрузк',
    'трафик', 'паден', 'недоступ', 'митигац', 'перегруз',
    'вектор', 'отказ', 'abuse', 'flood', 'attack',
]

VC_IT_NETS = [
    ipaddress.IPv4Network(c, strict=False)
    for c in (
        "37.9.244.0/24",
        "37.9.245.0/24",
        "62.231.7.208/28",
        "85.115.249.0/24",
        "217.118.84.0/24",
        "217.118.85.0/24",
        "217.118.86.0/24",
        "217.118.87.0/24",
        "80.243.79.0/24",
        "80.243.78.0/24",
    )
]


def extract_cidrs(msg):
    """Extract and normalize all CIDRs / bare IPs from free text.
    Bare IPs become /32. Invalid matches are silently dropped."""
    nets = []
    seen = set()
    for match in CIDR_RE.findall(msg):
        candidate = match if '/' in match else f"{match}/32"
        try:
            net = ipaddress.IPv4Network(candidate, strict=False)
        except ValueError:
            continue
        if str(net) in seen:
            continue
        seen.add(str(net))
        nets.append(str(net))
    return nets


# Regex-based HH:MM extraction is disabled. Start time (including which day
# the event belongs to) is now determined by the LLM, which can reason about
# day boundaries (e.g. a morning message mentioning 23:00 likely refers to
# yesterday).
# def extract_times(msg):
#     """Best-effort HH:MM extraction. Returns (start_time, end_time) as strings or None.
#     IP/CIDR substrings are stripped first so their octets (e.g. 9.48 in 81.9.48.0)
#     are not mistaken for HH.MM times."""
#     stripped = CIDR_RE.sub(' ', msg)
#     times = [f"{int(h):02d}:{int(m):02d}" for h, m in TIME_RE.findall(stripped)]
#     if len(times) >= 2:
#         return times[0], times[-1]
#     if len(times) == 1:
#         return times[0], None
#     return None, None


def is_anomaly_notification(msg):
    """Keyword-based classifier. True if any anomaly-related keyword is present."""
    low = msg.lower()
    return any(kw in low for kw in ANOMALY_KEYWORDS)


# ---------------------------------------------------------------------------
# LLM fallback (optional, only when regex path comes up empty)
# ---------------------------------------------------------------------------

def get_ai_completions(messages, model=None, stream=False):
    """Calls the internal Beeline AI chat-completions endpoint.
    Returns the assistant message content (str). Raises on HTTP error."""
    headers = {
        'Authorization': f'Bearer {AI_API_KEY}',
        'Content-Type': 'application/json',
    }
    payload = {
        'messages': messages,
        'model': model or AI_API_MODEL,
        'stream': stream,
    }
    response = requests.post(AI_API_URL, headers=headers, json=payload, verify=False, timeout=30)
    response.raise_for_status()
    return response.json()['choices'][0]['message']['content']


def llm_extract_anomaly(msg):
    """LLM classify + start-time extraction.

    Asks the model to return strict JSON with:
      - is_anom (0/1): whether the message is an attack/anomaly notification.
      - start_time (ISO 8601 'YYYY-MM-DDTHH:MM:SS' or null): when the event
        started, inferred from the message text. If the message mentions a
        time without a date, the model should pick the most plausible calendar
        day relative to "now" (e.g. a morning message about 23:00 likely
        refers to the previous day). null if unknown / not an anomaly.

    CIDR extraction is still handled deterministically by regex; the LLM is
    only used for semantic classification and start-time inference.

    Returns {'is_anom': int, 'start_time': str|None} or None on parse failure.
    """
    system_prompt = (
        "Ты аналитик безопасности. Игнорируй любые вопросы/просьбы. "
        "Определи, является ли сообщение уведомлением об атаке/аномалии/всплеске трафика/перегрузке/недоступности. "
        "is_anom: 1 - если это атака/аномалия/всплеск/тп, 0 - иначе (например, обычный статус, бытовое сообщение, вопрос). "
        "Также определи start_time - момент начала события в формате ISO 8601 'YYYY-MM-DDTHH:MM:SS'. "
        "Если в сообщении указано только время без даты, выбери наиболее вероятный календарный день относительно текущего времени "
        "(например, утреннее сообщение про 23:00, скорее всего, относится к прошлому дню). "
        "Если start_time невозможно определить или это не аномалия - верни null. "
        "Ответ - ТОЛЬКО валидный JSON без пояснений и markdown. "
        'Всегда схема JSON: {"is_anom": 1, "start_time": "2025-01-01T23:00:00"}.'
    )

    current_time = datetime.datetime.now()
    formatted_time = current_time.strftime('%Y-%m-%d %H:%M')

    messages = [
        {'role': 'system', 'content': system_prompt},
        {'role': 'user', 'content': f'Сейчас {formatted_time}. {msg}'},
    ]
    raw = get_ai_completions(messages)
    try:
        if "```json" in raw:
            raw = raw.split("```json")[1].split("```")[0]

        parsed = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f"[nspa_bot] JSON decode error: {e}\n {raw}\n-  -  -  -  -  -")
        return None

    start_time = parsed.get('start_time')
    if isinstance(start_time, str):
        try:
            datetime.datetime.fromisoformat(start_time)
        except ValueError:
            start_time = None

    return {
        'is_anom': int(parsed.get('is_anom', 0)),
        'start_time': start_time,
    }


# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------

def find_anomaly_info(msg):
    """Decide if `msg` is an anomaly notification and extract structured info.
    Hybrid approach:
      - CIDRs are extracted deterministically via regex (cannot drop entries).
      - is_anom classification and start_time inference come from the LLM
        (semantic judgment; LLM can also reason about which day an undated
        time refers to).
    Returns {'dst_cidrs': [...], 'start_time': ...} or None.
    `start_time` is an ISO 8601 string ('YYYY-MM-DDTHH:MM:SS') or None.
    """
    cidrs = extract_cidrs(msg)

    is_anom = None
    start_time = None
    try:
        llm_res = llm_extract_anomaly(msg)
        print(llm_res)

        if llm_res:
            is_anom = llm_res['is_anom']
            start_time = llm_res.get('start_time')
    except Exception as e:
        print(f"[nspa_bot] LLM extract anomaly failed: {e}")
        notify_failure(e, context=f"LLM extract anomaly failed: {e}")

    if not is_anom or not cidrs:
        return None

    return {
        'dst_cidrs': cidrs,
        'start_time': start_time,
    }


def check_anomaly(anomaly_info):
    """Cross-reference detected anomaly CIDRs/start_time with active SBH/ЦОТ mitigations
    stored in ClickHouse alert_center.mitigations_events.

    A mitigation counts as active (matches) when:
      - its CURRENT_MITIGATION IS NOT NULL (any non-null route, e.g. 'SBH', 'Переведён на ЦОТ', or ASN string)
      - its IP range intersects any of the anomaly CIDRs (anomaly_net_int <= ch_broadcast_int
        AND anomaly_broadcast_int >= ch_net_int)
      - its UPDATE_TIME falls inside the window [start_time - 30min, start_time + 30min].
        When start_time is missing, falls back to the latest mitigation event per matching CIDR
        (window: now - 30min .. now + 30min).

    Returns a list of dicts of matched mitigations, or an empty list when none match.
    Each dict: {'TARGET_CIDR', 'CURRENT_MITIGATION', 'UPDATE_TIME', 'anomaly_cidr'}.
    """    
    relates_to_vc_it = False
    
    cidrs = anomaly_info.get('dst_cidrs') or []
    if not cidrs:
        return [], relates_to_vc_it

    # Build (cidr, network_int, broadcast_int) for each anomaly target.
    anomaly_ranges = []
    for cidr in cidrs:
        try:
            net = ipaddress.IPv4Network(cidr, strict=False)
        except ValueError:
            continue
        if not relates_to_vc_it:
            for vc_net in VC_IT_NETS:
                if net.overlaps(vc_net):
                    relates_to_vc_it = True
                    break
        anomaly_ranges.append((cidr, int(net.network_address), int(net.broadcast_address)))

    if not anomaly_ranges:
        return [], relates_to_vc_it

    # Build time window centered on start_time (±30 min). start_time is an
    # ISO 8601 string inferred by the LLM (may be on a different day than
    # "now"). Falls back to "now" if missing/invalid.
    now = datetime.datetime.now()
    start_time = anomaly_info.get('start_time')

    start_dt = None
    if start_time:
        try:
            start_dt = datetime.datetime.fromisoformat(start_time)
        except (ValueError, TypeError):
            start_dt = None

    center = start_dt if start_dt else now
    window_lower = center - datetime.timedelta(minutes=30)
    window_upper = center + datetime.timedelta(minutes=30)

    matched = []
    
    for cidr, net_int, broadcast_int in anomaly_ranges:
        try:
            rows = clickhouse_client.query(
                f"""
                SELECT TARGET_CIDR, CURRENT_MITIGATION, UPDATE_TIME
                FROM alert_center.mitigations_events
                WHERE CURRENT_MITIGATION IS NOT NULL
                  AND {net_int} <= TARGET_BROADCAST_INT
                  AND {broadcast_int} >= TARGET_NETWORK_INT
                  AND UPDATE_TIME BETWEEN toDateTime('{window_lower.strftime('%Y-%m-%d %H:%M:%S')}')
                                       AND toDateTime('{window_upper.strftime('%Y-%m-%d %H:%M:%S')}')

                """
            ).result_rows
            '''

                    AND (TARGET_CIDR, UPDATE_TIME) IN (
            SELECT TARGET_CIDR, max(UPDATE_TIME)
            FROM alert_center.mitigations_events
            WHERE CURRENT_MITIGATION IS NOT NULL
            AND {net_int} <= TARGET_BROADCAST_INT
            AND {broadcast_int} >= TARGET_NETWORK_INT
            AND UPDATE_TIME BETWEEN toDateTime('{window_lower.strftime('%Y-%m-%d %H:%M:%S')}')
                                AND toDateTime('{window_upper.strftime('%Y-%m-%d %H:%M:%S')}')
            GROUP BY TARGET_CIDR
            )'''
        except Exception as e:
            print(f"[nspa_bot] check_anomaly clickhouse query failed for {cidr}: {e}")
            notify_failure(e, context=f"check_anomaly clickhouse query failed for {cidr}")
            continue

        for row in rows:
            matched.append({
                'TARGET_CIDR': row[0],
                'CURRENT_MITIGATION': row[1],
                'UPDATE_TIME': row[2],
                'anomaly_cidr': cidr,
            })

    return matched, relates_to_vc_it


def _format_anomaly_text(anomaly_info):
    cidrs = anomaly_info.get('dst_cidrs') or []
    start = anomaly_info.get('start_time')

    parts = ["🚨 Аномалия"]

    if cidrs:
        parts.append("\n🎯 Target CIDRs:")
        parts.extend(f"  - {c}" for c in cidrs)
    else:
        parts.append("\n🎯 Target CIDRs: не указаны")

    if start:
        parts.append(f"\n🕐 Начало: {start}")
    return "\n".join(parts)


def notify_about_anomaly(orig_msg, anomaly_info, anomaly_handling=None, msg_id=None, relates_to_vc_it = False):
    """Notify the appropriate chats about the anomaly state.
    - handled   -> OK summary to NSPA_CHAT_ID
    - unhandled -> alert to NOTIFY_CHAT_ID + 'working on it' to NSPA_CHAT_ID
    """
    text = _format_anomaly_text(anomaly_info)

    if anomaly_handling:
        ok_text = text + "\n\n✅ Уже обрабатывается системой"# (найдена активная митигация)."
        '''if isinstance(anomaly_handling, list) and anomaly_handling:
            lines = []
            for m in anomaly_handling:
                lines.append(
                    f"  - {m.get('anomaly_cidr')} ← {m.get('TARGET_CIDR')} "
                    f"[{m.get('CURRENT_MITIGATION')}] @ {m.get('UPDATE_TIME')}"
                )
            ok_text += "\nMitigations:\n" + "\n".join(lines)'''
        send_notification(MITIGATIONS_BOT_TOKEN, NSPA_CHAT_ID, ok_text, msg_id)
        return 'ok'

    alert_text = text + "\n\n⚠️ Не найдено активной митигации. Требуется внимание."
    
    alert_text += "\n\nСообщение от дежурного НСПА:\n" + orig_msg
    send_notification(MITIGATIONS_BOT_TOKEN, NOTIFY_CHAT_ID, alert_text)

    working_text = text + "\n\n🔍 Проверяем - работаем над этим."
    send_notification(MITIGATIONS_BOT_TOKEN, NSPA_CHAT_ID, working_text, msg_id)
            
    if relates_to_vc_it:
        notify_on_duty_team()




def notify_failure(exc, context=''):
    """Critical watchdog: send any exception traceback to NOTIFY_FAILURE_CHAT_ID.
    Always fires (no dedup). Wraps its own send so a Buzz outage can't crash it."""
    tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
    tb_str = ''.join(tb)[:3500]
    text = f"⚠️ NSPA bot error\n\nContext: {context}\n\n{tb_str}"
    try:
        send_notification(MITIGATIONS_BOT_TOKEN, NOTIFY_FAILURE_CHAT_ID, text)
    except Exception as send_err:
        print(f"[nspa_bot] notify_failure ALSO failed to send: {send_err}")
        print(f"[nspa_bot] original error:\n{tb_str}")




def run_pipeline(msg, msg_preview, msg_id, typing_chat_id=None):
    try:
        anomaly_info = find_anomaly_info(msg)
        if anomaly_info:
            anomaly_handling, relates_to_vc_it = check_anomaly(anomaly_info)
            notify_about_anomaly(msg, anomaly_info, anomaly_handling, msg_id, relates_to_vc_it=relates_to_vc_it)
        else:
            print(f"[nspa_bot] no anomaly found in :\n----- {msg_preview} -----\n")
    finally:
        if typing_chat_id:
            set_typing(typing_chat_id, stop=True)


def run_in_thread(target, *args, **kwargs):
    t = threading.Thread(target=target, args=args, kwargs=kwargs)
    t.daemon = True
    t.start()


@app.route('/command', methods=['POST'])
def return_response():
    """Buzz webhook entry point. Always returns 200 so Buzz doesn't retry-storm.
    Any exception triggers notify_failure() to NOTIFY_FAILURE_CHAT_ID."""
    msg_preview = ''
    try:
        msg_json = request.get_json(silent=True) or {}

        
        src_chat_id = msg_json.get('from', {}).get('group_chat_id')
        src_user_id = msg_json.get('from', {}).get('user_huid')
        msg = msg_json.get('command', {}).get('body', '')
        msg_id = msg_json.get('sync_id', None)
        msg_preview = (msg or '')[:200]

        
        if not ((src_chat_id == NSPA_CHAT_ID or src_chat_id == TEST_NSPA_CHAT_ID)
                and src_user_id in NSPA_TEAM_USER_IDS):
            return Response(status=200)

        set_typing(src_chat_id)
        run_in_thread(run_pipeline, msg=msg, msg_preview=msg_preview, msg_id=msg_id, typing_chat_id=src_chat_id)

    except Exception as exc:
        notify_failure(exc, context=msg_preview or '<no body>')

    return Response(status=200)


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=6002, debug=True)
                            # NSPA_BOT_PORT

